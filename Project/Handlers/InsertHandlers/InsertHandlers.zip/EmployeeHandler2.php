<?php 
 // Handle Employee
 $skip=0;
 $datapath="";
 $values="";
 if (($h = fopen('InsertHandlers\DataSet\Employee.csv', "r") )!== FALSE) {
    while (($data = fgetcsv($h, 1000, ",")) !== FALSE) {
        if($skip==0) {   
            $skip=$skip+1;        
        }
        else {
            $dataPath="UPDATE EMPLOYEE SET BranchID=".$data[10]." WHERE Empno=".(int)$data[0];
            $query=$dataPath;
            $parse=oci_parse($con,$query);
            $execute=oci_execute($parse);
        }
    }
}
    fclose($h);
?>