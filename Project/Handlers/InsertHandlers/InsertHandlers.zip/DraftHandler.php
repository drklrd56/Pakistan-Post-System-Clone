<?php 
 // Handle Draft
 $skip=0;
 $datapath="";
 $values="";
 //TicketID,Description
 if (($h = fopen('InsertHandlers\DataSet\Draft.csv', "r") )!== FALSE) {
    while (($data = fgetcsv($h, 1000, ",")) !== FALSE) {
        if($skip==0) {   
            $dataPath="INSERT INTO Draft(TicketID".",".$data[1].")Values(";
            $skip=$skip+1;        
        }
        else {
            $values=(int)$data[0].",".(int)$data[1].")";
            $query=$dataPath.$values;
            $parse=oci_parse($con,$query);
            $execute=oci_execute($parse);
        }
    }
}
    fclose($h);
?>