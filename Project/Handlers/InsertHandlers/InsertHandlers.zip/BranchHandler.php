<?php 
 // Handle BrachOffice
 $skip=0;
 $datapath="";
 $values="";
 //PostalCode,Name,OfficeType,Head,ContactNumber,Street,City,Province
 if (($h = fopen('InsertHandlers\DataSet\PostOffice.csv', "r") )!== FALSE) {
    while (($data = fgetcsv($h, 1000, ",")) !== FALSE) {
        if($skip==0) {   
            $dataPath="INSERT INTO POST_OFFICE(POSTALCODE".",".$data[1].",".$data[2].",".$data[3].",".$data[4].
            ",".$data[5].",".$data[6].",".$data[7].")Values(";
            $skip=$skip+1;        
        }
        else {
            $data[4]=preg_replace("/-/", "", $data[4]);
            $values=(int)$data[0].",'".$data[1]."','".$data[2]."',".(int)$data[3].",".(int)$data[4].
            ",'".$data[5]."','".$data[6]."','".$data[7]."')";
            $query=$dataPath.$values;
            $parse=oci_parse($con,$query);
            $execute=oci_execute($parse);
        }
    }
}
    fclose($h);
?>
