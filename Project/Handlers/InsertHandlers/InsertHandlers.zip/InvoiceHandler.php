<?php 
 // Handle Invoice
 $skip=0;
 $datapath="";
 $values="";
 //InvoiceID,CustomerID,Type,InDate,Empno
 if (($h = fopen('InsertHandlers\DataSet\Invoice.csv', "r") )!== FALSE) {
    while (($data = fgetcsv($h, 1000, ",")) !== FALSE) {
        if($skip==0) {   
            $dataPath="INSERT INTO INVOICE(InvoiceID".",".$data[1].",".$data[2].",".$data[3].",".$data[4].")Values(";
            $skip=$skip+1;        
        }
        else {
            $daat="to_date("."'".$data[3]."','DD-MM-YYYY')";
            $values=(int)$data[0].",".(int)$data[1].",".(int)$data[2].",".$daat.",".(int)$data[4].")";
            $query=$dataPath.$values;
            $parse=oci_parse($con,$query);
            $execute=oci_execute($parse);
        }
    }
}
    fclose($h);
?>