<?php 
 // Handle Stamp
 $skip=0;
 $datapath="";
 $values="";
 //TicketID,Description
 if (($h = fopen('InsertHandlers\DataSet\Stamp.csv', "r") )!== FALSE) {
    while (($data = fgetcsv($h, 1000, ",")) !== FALSE) {
        if($skip==0) {   
            $dataPath="INSERT INTO Stamp(TicketID".",".$data[1].")Values(";
            $skip=$skip+1;        
        }
        else {
            $values=(int)$data[0].",'".$data[1]."')";
            $query=$dataPath.$values;
            $parse=oci_parse($con,$query);
            $execute=oci_execute($parse);
        }
    }
}
    fclose($h);
?>